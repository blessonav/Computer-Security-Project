Wireshark Assignment(B110087CS)
//Brought a ticket from IRCTC

5_1 displays packets exchanged between client and IRCTC
5_2 displays packets exchanged between Client and payment portal(onlinesbi)
6 was continuation of 5th so n/a
7 displays packets after clearing all filters
8 displays all TLS/SSL packets
9 displays the filtered packet stream with packets corresponding to a run of SSL  protocol marked
10_1,10_2,10_3,10_4 and 10_5 displays packets exchanged as per SSL handshake protocol and SSL record protocol during ticket booking.
10_6_1 displays packet content having encrypted application data
10_6_2 displays TCP stream corresponding to that.
IRCTC.pcapng is the saved capture file
